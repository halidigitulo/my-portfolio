<a href="{{ $profile->facebook }}" target="_blank"><i class="bi bi-facebook"></i></a>
                        <a href="{{ $profile->instagram }}" target="_blank" class="instagram"><i
                                class="bi bi-instagram"></i></a>
                        <a href="{{ $profile->tiktok }}" target="_blank" class="tiktok"><i class="bi bi-tiktok"></i></a>
                        <a href="{{ $profile->youtube }}" target="_blank" class="youtube"><i
                                class="bi bi-youtube"></i></a>
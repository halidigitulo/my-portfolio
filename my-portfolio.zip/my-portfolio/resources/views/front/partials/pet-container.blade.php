<div id="pet-container">
    <img class="walking-pet" id="cat" src="{{ asset('front/img/pets/cat.gif') }}" alt="Cat">
    <img class="walking-pet" id="dog" src="{{ asset('front/img/pets/dog.gif') }}" alt="Dog">
    <img class="walking-pet" id="fox" src="{{ asset('front/img/pets/fox.gif') }}" alt="Fox">
    <img class="walking-pet" id="chicken" src="{{ asset('front/img/pets/chicken.gif') }}" alt="Chicken">
    <img class="walking-pet" id="pig" src="{{ asset('front/img/pets/pig.gif') }}" alt="Pig">
    <img class="walking-pet" id="snail" src="{{ asset('front/img/pets/snail.gif') }}" alt="Snail">
    <img class="walking-pet" id="turtle" src="{{ asset('front/img/pets/turtle.gif') }}" alt="Turtle">
    <img class="walking-pet" id="mario" src="{{ asset('front/img/pets/mario.gif') }}" alt="Mario">
</div>

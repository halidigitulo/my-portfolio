<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KategoriStack extends Model
{
    protected $guarded = [];
    protected $table = 'kategori_stack';
}

<?php $__env->startSection('title', 'FAQ'); ?>
<?php $__env->startSection('sub-title', 'Frequently Asked Questions'); ?>
<?php $__env->startSection('meta_description', 'Find answers to the most commonly asked questions about our services, policies, and
    procedures. Our FAQ section is designed to help you get the information you need quickly and easily.'); ?>
<?php $__env->startSection('meta_keywords', 'FAQ, frequently asked questions, help, support, customer service, policies, procedures'); ?>
<?php $__env->startSection('content'); ?>

    <section id="starter-section" class="starter-section section">
        <!-- Section Title -->
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div><!-- End Section Title -->

        <section id="service-details" class="service-details section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="row gy-5">
                    <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
                        <div class="service-content">
                            

                            <div class="service-features">
                                <div class="accordion" id="faqAccordion">
                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                                                <button class="accordion-button <?php echo e($index != 0 ? 'collapsed' : ''); ?>"
                                                    type="button" data-bs-toggle="collapse"
                                                    data-bs-target="#collapse<?php echo e($index); ?>"
                                                    aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                                                    aria-controls="collapse<?php echo e($index); ?>">
                                                    <i
                                                        class="bi <?php echo e($index == 0 ? 'bi-chevron-down' : 'bi-chevron-right'); ?> accordion-icon"></i>
                                                    <?php echo e($faq->question); ?>

                                                </button>
                                            </h2>
                                            <div id="collapse<?php echo e($index); ?>"
                                                class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>"
                                                aria-labelledby="heading<?php echo e($index); ?>" data-bs-parent="#faqAccordion">
                                                <div class="accordion-body">
                                                    <?php echo nl2br(e($faq->answer)); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </section><!-- /Service Details Section -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/others/faq.blade.php ENDPATH**/ ?>
<div class="row my-3">
    <div class="col">
        <form id="form_general">
            <?php echo csrf_field(); ?>
            <div class="row">
                <h5 class="py-1 my-1">Hero Section</h5>
                <div class="col-md-12 mb-3">
                        <label for="hero_title" class="form-label">Hero Title</label>
                        <input type="text" name="hero_title" id="hero_title" class="form-control" value="<?php echo e(old('hero_title', $general->hero_title)); ?>">
                </div>
                <div class="col-md-12 mb-3">
                        <label for="hero_text" class="form-label">Hero Text</label>
                        <textarea name="hero_text" id="hero_text" cols="30" rows="3" class="form-control"><?php echo e(old('hero_text', $general->hero_text)); ?></textarea>
                </div>
                <div class="col-md-4 mb-3">
                        <label for="projects" class="form-label">Projects</label>
                        <input type="number" min="0" class="form-control" name="projects" id="projects" placeholder="projects"
                            value="<?php echo e(old('projects', $general->projects)); ?>" >
                </div>
                <div class="col-md-4 mb-3">
                        <label for="clients" class="form-label">Clients</label>
                        <input type="number" min="0" class="form-control" name="clients" id="clients" placeholder="clients"
                            value="<?php echo e(old('clients', $general->clients)); ?>" >
                </div>
                <div class="col-md-4 mb-3">
                        <label for="experiences" class="form-label">Experiences</label>
                        <input type="number" min="0" class="form-control" name="experiences" id="experiences"
                            placeholder="experiences" value="<?php echo e(old('experiences', $general->experiences)); ?>" >
                </div>
                <div class="col-md-12 mb-3">
                    <label for="cta_text" class="form-label">CTA Text</label>
                    <input type="text" name="cta_text" id="cta_text" class="form-control" value="<?php echo e(old('cta_text', $general->cta_text)); ?>" >
                </div>
                <h5 class="py-1 my-1">Pets Settings</h5>
                <div class="col-md-4 mb-3">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="pets_enabled" name="pets_enabled" <?php echo e($general->pets_enabled ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="pets_enabled">Enable Walking Pets</label>
                    </div>  
                </div>
                <h5 class="py-1 my-1">WA Custome Text</h5>
                <div class="col-md-12 mb-3">
                    <input type="text" name="wa_text" id="wa_text" class="form-control" value="<?php echo e(old('wa_text', $general->wa_text)); ?>" >
                </div>
                
                <div class="mt-3">
                    <button class="btn btn-primary" type="submit"><i class="ri-send-plane-line"></i>
                        Submit</button>
                </div>
                
            </div>
        </form>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#form_general').on('submit', function(e) {
                e.preventDefault();

                // Use FormData for file uploads
                let formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('general.update')); ?>",
                    data: formData,
                    contentType: false,
                    processData: false,
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        Swal.fire({
                            position: "top-end",
                            icon: 'success',
                            title: 'Sukses',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1000,
                            toast: true,
                            background: '#28a745',
                            color: '#fff'
                        });

                        // Update logo preview if provided in the response
                        if (response.general) {
                            // Update text fields
                            $('#clients').val(response.general.clients);
                            $('#experiences').val(response.general.experiences);
                            $('#projects').val(response.general.projects);
                        }
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            let errorMessage = '';
                            $.each(errors, function(key, value) {
                                errorMessage += value + '<br>';
                            });
                            Swal.fire({
                                title: 'Error!',
                                html: errorMessage,
                                icon: 'error',
                                position: 'top-end',
                                width: '400px',
                                showConfirmButton: false,
                                timer: 3000,
                                toast: true,
                                background: '#dc3545',
                                color: '#fff'
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: 'Something went wrong. Please try again.',
                                icon: 'error',
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                toast: true,
                                background: '#dc3545',
                                color: '#fff'
                            });
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/admin/master/general.blade.php ENDPATH**/ ?>
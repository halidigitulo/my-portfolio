<nav id="navmenu" class="navmenu">

    <div class="profile-img">
        <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>" alt="<?php echo e($profile->nama); ?>" title="<?php echo e($profile->nama); ?>"
            class="img-fluid rounded-circle">
    </div>

    <a href="/" class="logo d-flex align-items-center justify-content-center active">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="<?php echo e(asset('front')); ?>/img/logo.webp" alt=""> -->
        <h1 class="sitename"><?php echo e($profile->nama ?? ''); ?></h1>
    </a>

    <div class="social-links text-center">
        <?php echo $__env->make('front.partials.socmed', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <ul>
        <li><a href="#hero">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#resume">Resume</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#products">Products</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="/login">Login</a></li>
    </ul>
    <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
</nav>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/partials/menu.blade.php ENDPATH**/ ?>
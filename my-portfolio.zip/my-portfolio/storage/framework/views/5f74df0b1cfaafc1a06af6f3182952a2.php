<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('front.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="index-page">
    <header id="header" class="header d-flex align-items-center fixed-top">
        <div class="container-fluid position-relative d-flex align-items-center justify-content-between">
            
                <!-- Uncomment the line below if you also wish to use an image logo -->
                
                <!-- Uncomment the line below if you also wish to use an text logo -->
                <!-- <h1 class="sitename">Style</h1>  -->
            
            <?php echo $__env->make('front.partials.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </header>

    <main class="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('front.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('front.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/partials/app.blade.php ENDPATH**/ ?>
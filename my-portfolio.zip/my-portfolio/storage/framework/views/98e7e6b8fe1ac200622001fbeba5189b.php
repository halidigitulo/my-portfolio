<!-- Faq Section -->
<section id="faq" class="faq section">

    <!-- Section Title -->
    <div class="container section-title">
        <h2>Frequently Asked Questions</h2>
        <p>Temukan jawaban atas pertanyaan umum tentang layanan dan produk kami.</p>
    </div><!-- End Section Title -->

    <div class="container">

        <div class="row justify-content-center">

            <div class="col-lg-12" data-aos="fade-up" data-aos-delay="100">

                <div class="faq-container">

                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="faq-item">
                            <h3><?php echo e($item->question); ?></h3>
                            <div class="faq-content">
                                <p><?php echo e($item->answer); ?></p>
                            </div>
                            <i class="faq-toggle bi bi-chevron-right"></i>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    

                </div>

            </div><!-- End Faq Column-->

        </div>

    </div>

</section><!-- /Faq Section -->
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/homepage/faq.blade.php ENDPATH**/ ?>
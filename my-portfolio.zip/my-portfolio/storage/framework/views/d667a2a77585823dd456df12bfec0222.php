<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('sub-title', 'Learn More About Us'); ?>
<?php $__env->startSection('meta_description', 'Discover more about our mission, values, and the team behind our services. We are
    dedicated to providing exceptional solutions and building lasting relationships with our clients.'); ?>
<?php $__env->startSection('meta_keywords', 'about us, company information, mission, values, team, services, solutions'); ?>
<?php $__env->startSection('content'); ?>

    <section id="starter-section" class="starter-section section">
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div>

        <section id="service-details" class="service-details section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="row gy-5">
                    <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
                        <section id="about" class="about section">
                            <div class="container" data-aos="fade-up" data-aos-delay="100">
                                <div class="row align-items-center gy-5">
                                    <div class="col-lg-12" data-aos="fade-right" data-aos-delay="200">
                                        <div class="profile-image-wrapper">
                                            <div class="profile-image">
                                                
                                                <img src="<?php echo e(asset('uploads/' . $profile->hero)); ?>" alt="Profile"
                                                    class="img-fluid" style="height: 350px; width:100%; object-fit:cover">
                                            </div>
                                            <div class="signature-section">
                                                <img src="<?php echo e(asset('uploads/' . $profile->signature)); ?>" alt="Signature"
                                                    class="signature">
                                                
                                                <p class="quote"><?php echo e($profile->tagline ?? ''); ?>.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12" data-aos="fade-left" data-aos-delay="300">
                                        <div class="about-content">
                                            <div class="intro">
                                                <h2>Halo, Saya <?php echo e($profile->direktur); ?> dari <?php echo e($profile->nama); ?></h2>
                                                <p><?php echo $profile->isi; ?></p>
                                            </div>
                                            <div class="skills-grid">
                                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        // Hitung delay animasi otomatis (misal: 300, 400, 500, ...)
                                                        $delay = 300 + $index * 100;
                                                    ?>
                                                    <div class="skill-item" data-aos="zoom-in"
                                                        data-aos-delay="<?php echo e($delay); ?>">
                                                        <div class="skill-icon">
                                                            <i class="bi bi-<?php echo e($item->icon); ?>"></i>
                                                        </div>
                                                        <h4><?php echo e($item->judul); ?></h4>
                                                        <p><?php echo $item->deskripsi; ?></p>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="journey-timeline" data-aos="fade-up" data-aos-delay="300">
                                                <?php $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="timeline-item">
                                                        <div class="year"><?php echo e($item->mulai_dari); ?></div>
                                                        <div class="description"><?php echo $item->deskripsi; ?></div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="cta-section" data-aos="fade-up" data-aos-delay="400">
                                                <div class="fun-fact">
                                                    <span class="emoji">☕</span>
                                                    <span class="text"><?php echo e($generalsettings->cta_text); ?></span>
                                                </div>
                                                <div class="action-buttons">
                                                    <a href="/projects" class="btn btn-primary">Lihat Portfolio</a>
                                                    <a href="#" class="btn btn-outline">Download Resume</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </section><!-- /Service Details Section -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/others/about.blade.php ENDPATH**/ ?>
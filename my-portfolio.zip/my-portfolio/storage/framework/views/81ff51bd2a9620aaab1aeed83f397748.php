<?php $__env->startSection('title', 'Posts'); ?>
<?php $__env->startSection('sub-title', 'Informasi bermanfaat'); ?>
<?php $__env->startSection('content'); ?>

    <section id="starter-section" class="starter-section section">

        <!-- Section Title -->
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div><!-- End Section Title -->

        <section id="service-details" class="service-details section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="container">
                    <div class="row gy-5">
                        <!-- Latest Post -->
                        <div class="row">
                            <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
                                <div class="row">
                                    <?php if($latestPost): ?>
                                        <div class="latest-post-card mb-4">
                                            <!-- Thumbnail -->
                                            <?php if(!$latestPost->thumbnail): ?>
                                                <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>"
                                                    alt="<?php echo e($profile->nama); ?>" class="img-fluid w-100 rounded"
                                                    style="height: 350px; object-fit:cover">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('uploads/posts/' . $latestPost->thumbnail)); ?>"
                                                    alt="<?php echo e($profile->nama); ?>" class="img-fluid w-100 rounded"
                                                    style="height: 350px; object-fit:cover">
                                            <?php endif; ?>
                                            <!-- Post Info -->
                                            <div class="latest-post-info">
                                                <h2><?php echo e($latestPost->judul); ?></h2>
                                                <p><strong>By:</strong> <?php echo e($profile->nama); ?> | <strong>Date:</strong>
                                                    <?php echo e($latestPost->created_at->format('d M Y')); ?></p>
                                                <div class="latest-post-description">
                                                    <p><?php echo Str::limit($latestPost->deskripsi, 150); ?></p>
                                                </div>
                                                <a href="<?php echo e(route('post.detail', $latestPost->slug)); ?>"
                                                    class="btn btn-outline-danger"><i class="bi bi-arrow-right"></i> Read
                                                    More</a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="row">
                                    <section id="portfolio" class="portfolio section">
                                        <!-- All Posts -->
                                        <div class="container" data-aos="fade-up" data-aos-delay="100">
                                            <div class="isotope-layout" data-default-filter="*" data-layout="masonry"
                                                data-sort="original-order">
                                                <div class="row g-4 isotope-container" data-aos="fade-up"
                                                    data-aos-delay="300">

                                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div
                                                            class="col-lg-4 col-md-6 portfolio-item isotope-item filter-<?php echo e($item->kategori->id); ?>">
                                                            <article class="portfolio-entry">
                                                                <figure class="entry-image">
                                                                    <?php if(!$item->thumbnail): ?>
                                                                        <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>"
                                                                            alt="<?php echo e($profile->nama); ?>"
                                                                            class="img-fluid w-100 rounded"
                                                                            style="height: 200px; object-fit:cover;">
                                                                    <?php else: ?>
                                                                        <img src="<?php echo e(asset('uploads/posts/' . $item->thumbnail)); ?>"
                                                                            class="img-fluid w-100 rounded" alt="<?php echo e($item->judul); ?>"
                                                                            loading="lazy">
                                                                    <?php endif; ?>
                                                                    <div class="entry-overlay">
                                                                        <div class="overlay-content">
                                                                            
                                                                            <h3 class="entry-title"><?php echo e($item->judul); ?>

                                                                            </h3>
                                                                            <div class="entry-links">
                                                                                <a href="<?php echo e(asset('uploads/posts/' . $item->thumbnail)); ?>"
                                                                                    class="glightbox"
                                                                                    data-gallery="portfolio-gallery-ui"
                                                                                    data-glightbox="title: <?php echo e($item->judul); ?>; description: <?php echo e($item->deskripsi); ?>">
                                                                                    <i
                                                                                        class="bi bi-arrows-angle-expand"></i>
                                                                                </a>
                                                                                <a
                                                                                    href="<?php echo e(route('post.detail', $item->slug)); ?>">
                                                                                    <i class="bi bi-arrow-right"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </figure>
                                                            </article>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                            <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>

                        <!-- Random Posts (3 Posts) -->
                        
                    </div>

                </div>

            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/post/index.blade.php ENDPATH**/ ?>
 <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('front')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/php-email-form/validate.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/aos/aos.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/typed.js/typed.umd.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/waypoints/noframework.waypoints.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="<?php echo e(asset('front')); ?>/vendor/swiper/swiper-bundle.min.js"></script>

    <!-- Main JS File -->
    <script src="<?php echo e(asset('front')); ?>/js/main.js"></script><?php /**PATH C:\laragon\www\portfolio\resources\views/front/partials/scripts.blade.php ENDPATH**/ ?>
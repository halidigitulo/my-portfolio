<a href="<?php echo e($profile->facebook); ?>" target="_blank"><i class="bi bi-facebook"></i></a>
                        <a href="<?php echo e($profile->instagram); ?>" target="_blank" class="instagram"><i
                                class="bi bi-instagram"></i></a>
                        <a href="<?php echo e($profile->tiktok); ?>" target="_blank" class="tiktok"><i class="bi bi-tiktok"></i></a>
                        <a href="<?php echo e($profile->youtube); ?>" target="_blank" class="youtube"><i
                                class="bi bi-youtube"></i></a><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/partials/socmed.blade.php ENDPATH**/ ?>
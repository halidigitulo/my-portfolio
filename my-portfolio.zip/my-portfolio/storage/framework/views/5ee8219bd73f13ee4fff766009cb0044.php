<div class="col-lg-4" data-aos="fade-up" data-aos-delay="400">
    <div class="service-sidebar">

        <div class="service-menu">
            <h4>Layanan Kami</h4>
            <div class="menu-list">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="menu-item active">
                        
                        <i class="bi bi-<?php echo e($item->icon ? $item->icon : 'arrow-right'); ?>"></i>
                        <span><?php echo e($item->judul); ?></span>
                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        

        <div class="contact-card">
            <div class="contact-content">
                <h4>Butuh Bantuan?</h4>
                <p>Jangan ragu hubungi kami untuk informasi lebih lanjut.</p>
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="bi bi-whatsapp"></i>
                        <span><?php echo e($profile->telp); ?></span>
                    </div>
                    <div class="contact-item">
                        <i class="bi bi-envelope"></i>
                        <span><?php echo e($profile->email); ?></span>
                    </div>
                </div>
                <a href="https://api.whatsapp.com/send?phone=<?php echo e($profile->telp); ?>&amp;text=<?php echo e(urlencode($generalsettings->wa_text)); ?>"
                    target="_blank" class="btn btn-primary"><i class="bi bi-whatsapp"></i> Kirim Pesan Sekarang</a>
            </div>
        </div>

        <div class="mt-3">
            <a href="https://www.dewaweb.com/aff.php?aff=29114" target="_blank">
                <img src="<?php echo e(asset('uploads/ads/dewaweb-affiliate-banner-01-336x280px-1.gif')); ?>" alt="" class="img-fluid rounded w-100">
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/others/sidebar.blade.php ENDPATH**/ ?>
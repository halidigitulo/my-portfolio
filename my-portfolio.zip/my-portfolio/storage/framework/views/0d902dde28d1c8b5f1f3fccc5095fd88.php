 <!-- Resume Section -->
    <section id="resume" class="resume section">

      <!-- Section Title -->
      <div class="container section-title">
        <h2>Resume</h2>
        <p>Lihat perjalanan profesional kami dan pencapaian kami dalam menghadirkan solusi digital terbaik.</p>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row">
          <div class="col-lg-6" data-aos="fade-right" data-aos-delay="200">
            <div class="experience-section">
              <div class="section-header">
                <h2><i class="bi bi-briefcase"></i> Professional Journey</h2>
                
              </div>

              <div class="experience-cards">
                <?php $__currentLoopData = $profesional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <div class="experience-card" data-aos="zoom-in" data-aos-delay="300">
                  <div class="card-header">
                    <div class="role-info">
                      <h3><?php echo e($item->judul); ?></h3>
                      <h4><?php echo e($item->lokasi); ?></h4>
                    </div>
                    <span class="duration"><?php echo e($item->mulai_dari); ?> - <?php echo e($item->sampai_dengan); ?></span>
                  </div>
                  <div class="card-body">
                    <p><?php echo $item->deskripsi; ?></p>
                    
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>

          <div class="col-lg-6" data-aos="fade-left" data-aos-delay="200">
            <div class="education-section">
              <div class="section-header">
                <h2><i class="bi bi-mortarboard"></i> Academic Excellence</h2>
                
              </div>

              <div class="education-timeline">
                <div class="timeline-track"></div>
                <?php $__currentLoopData = $akademik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <div class="education-item" data-aos="slide-up" data-aos-delay="300">
                  <div class="timeline-marker"></div>
                  <div class="education-content">
                    <div class="degree-header">
                      <h3><?php echo e($item->judul); ?></h3>
                      <span class="year"><?php echo e($item->mulai_dari); ?> - <?php echo e($item->sampai_dengan); ?></span>
                    </div>
                    <h4 class="institution"><?php echo e($item->lokasi); ?></h4>
                    <p><?php echo e($item->deskripsi); ?></p>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
              </div>
            </div>
          </div>
        </div>

      </div>

    </section><!-- /Resume Section --><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/homepage/resume.blade.php ENDPATH**/ ?>
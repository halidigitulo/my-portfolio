<div class="row my-3">
    <div class="col">
        <form id="form_terms">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12 mb-3">
                    
                    <textarea name="terms" id="terms" cols="30" rows="10" class="form-control"><?php echo e(old('terms', $general->terms)); ?></textarea>
                </div>
                <div class="mt-3">
                    <button class="btn btn-primary" type="submit"><i class="ri-send-plane-line"></i>
                        Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php echo $__env->make('plugins.summernote', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            // $('#terms').summernote({
            //     height: 300,
            //     placeholder: 'Tulis Terms & Conditions di sini...',
            // });

            $('#form_terms').on('submit', function(e) {
                e.preventDefault();

                // Use FormData for file uploads
                let formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('other.update')); ?>",
                    data: formData,
                    contentType: false,
                    processData: false,
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        Swal.fire({
                            position: "top-end",
                            icon: 'success',
                            title: 'Sukses',
                            text: response.message,
                            showConfirmButton: false,
                            timer: 1000,
                            toast: true,
                            background: '#28a745',
                            color: '#fff'
                        });

                        if (response.general && response.general.terms) {
                            // Update konten summernote dengan data terbaru
                            $('#terms').summernote('code', response.general.terms);
                        }
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            let errorMessage = '';
                            $.each(errors, function(key, value) {
                                errorMessage += value + '<br>';
                            });
                            Swal.fire({
                                title: 'Error!',
                                html: errorMessage,
                                icon: 'error',
                                position: 'top-end',
                                width: '400px',
                                showConfirmButton: false,
                                timer: 3000,
                                toast: true,
                                background: '#dc3545',
                                color: '#fff'
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: 'Something went wrong. Please try again.',
                                icon: 'error',
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                toast: true,
                                background: '#dc3545',
                                color: '#fff'
                            });
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/admin/master/terms.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Terms and Conditions'); ?>
<?php $__env->startSection('sub-title', 'Our Terms and Conditions'); ?>
<?php $__env->startSection('meta_description', 'Read our detailed terms and conditions to understand the rules and guidelines for using our services. We are committed to transparency and ensuring a safe experience for all our users.'); ?>
<?php $__env->startSection('meta_keywords', 'terms and conditions, user agreement, policies, rules, guidelines, service terms, legal'); ?>
<?php $__env->startSection('content'); ?>

    <section id="starter-section" class="starter-section section">

        <!-- Section Title -->
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div><!-- End Section Title -->

        <section id="service-details" class="service-details section">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row gy-5">

                    <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
                        <div class="service-content">
                            <div class="service-features">
                                <?php echo $generalsettings->terms; ?>

                            </div>
                        </div>
                    </div>

                    <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                </div>

            </div>

        </section><!-- /Service Details Section -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/others/terms.blade.php ENDPATH**/ ?>
<div class="row my-3">
                    <div class="col-md-12">
                        <a href="https://www.dewaweb.com/aff.php?aff=29114" target="_blank">
                            <img src="<?php echo e(asset('uploads/ads/dewaweb-affiliate-banner-02-728x90px.gif')); ?>" alt=""
                                class="rounded w-100 img-fluid">
                        </a>
                    </div>
                </div><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/partials/banner.blade.php ENDPATH**/ ?>
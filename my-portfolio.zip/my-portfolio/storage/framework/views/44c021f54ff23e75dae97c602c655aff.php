<?php $__env->startSection('title', 'Layanan'); ?>
<?php $__env->startSection('sub-title', 'Kami menawarkan layanan mulai dari desain kreatif hingga pengembangan sistem web dan keamanan.'); ?>
<?php $__env->startSection('meta_description',
    'Discover our comprehensive range of services designed to elevate your business. From
    digital marketing to web development, we provide tailored solutions that drive growth and success.'); ?>
<?php $__env->startSection('meta_keywords', 'services, digital marketing, web development, SEO, content creation, brand strategy'); ?>
<?php $__env->startSection('content'); ?>

    <section id="starter-section" class="starter-section section">

        <!-- Section Title -->
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div><!-- End Section Title -->

        <section id="service-details" class="service-details section">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row gy-5">

                    <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
                        <div class="service-hero">
                            <?php if(!$profile->cover): ?>
                                <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>" alt="<?php echo e($profile->nama); ?>"
                                    class="img-fluid">
                            <?php else: ?>
                                <img src="<?php echo e(asset('uploads/' . $profile->cover)); ?>" alt="<?php echo e($profile->nama); ?>"
                                    class="img-fluid">
                            <?php endif; ?>
                            <div class="service-badge">
                                <span><?php echo e($profile->nama); ?> | <?php echo e($profile->tagline); ?></span>
                            </div>
                        </div>

                        <div class="service-content">
                            <div class="service-header">
                                <h2><?php echo e($profile->nama); ?></h2>
                                <p class="service-intro"><?php echo $profile->isi; ?></p>
                            </div>

                            <div class="service-features">
                                <h4>Apa yang kami berikan</h4>
                                <div class="row gy-3">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="feature-item">
                                                <div class="feature-icon">
                                                    <i class="bi bi-<?php echo e($item->icon); ?>"></i>
                                                </div>
                                                <div class="feature-content">
                                                    <h5><?php echo e($item->judul); ?></h5>
                                                    <p><?php echo e($item->deskripsi); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="service-process">
                                <h4>Proses Pengerjaan dari Kami</h4>
                                <div class="process-steps">
                                    <div class="process-step">
                                        <div class="step-number">01</div>
                                        <div class="step-content">
                                            <h5>Perencanaan & Analisis</h5>
                                            <p>Memulai proyek dengan memahami kebutuhan klien dan menetapkan tujuan jelas.
                                                Kami menganalisis audiens, fitur utama, dan anggaran untuk memastikan
                                                fondasi yang kokoh.</p>
                                        </div>
                                    </div>
                                    <div class="process-step">
                                        <div class="step-number">02</div>
                                        <div class="step-content">
                                            <h5>Desain & Pengembangan</h5>
                                            <p>Mengubah ide menjadi desain visual menarik, kemudian membangun aplikasi atau
                                                website dengan kode yang efisien dan fungsionalitas yang optimal.</p>
                                        </div>
                                    </div>
                                    <div class="process-step">
                                        <div class="step-number">03</div>
                                        <div class="step-content">
                                            <h5>Uji Coba & Penyempurnaan</h5>
                                            <p>Menguji produk secara menyeluruh untuk memastikan kualitas, stabilitas, dan
                                                keamanan. Kami menyempurnakan setiap elemen agar siap digunakan tanpa
                                                masalah.</p>
                                        </div>
                                    </div>
                                    <div class="process-step">
                                        <div class="step-number">04</div>
                                        <div class="step-content">
                                            <h5>Serah Terima & Pelatihan</h5>
                                            <p>Setelah semuanya siap, kami menyerahkan produk akhir dengan pelatihan dan
                                                dokumentasi lengkap, memastikan klien dapat mengelola proyek dengan mudah.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="service-gallery" data-aos="fade-up" data-aos-delay="300">
                                <h4>Project Showcase</h4>
                                <div class="row gy-3">
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <a href="<?php echo e(route('project.detail', $item->slug)); ?>">
                                                <img src="<?php echo e(asset('uploads/projects/' . $item->thumbnail)); ?>"
                                                    alt="<?php echo e($item->judul); ?>" class="img-fluid rounded"
                                                    style="width:100%; height: 200px; object-fit:cover">
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                </div>

            </div>

        </section><!-- /Service Details Section -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/others/services.blade.php ENDPATH**/ ?>
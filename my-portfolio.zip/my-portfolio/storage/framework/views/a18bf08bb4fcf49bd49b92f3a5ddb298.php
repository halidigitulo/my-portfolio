<div class="row my-3">
    <div class="col-md-6">
        <form id="form_terms">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="terms" class="form-label fw-bold">Terms & Policy</label>
                <textarea name="terms" id="terms" cols="30" rows="10" class="form-control"><?php echo e(old('terms', $general->terms)); ?></textarea>
                <small id="autosave-terms" class="text-muted d-block mt-2 fst-italic">Belum ada penyimpanan
                    otomatis</small>
            </div>
            <button class="btn btn-primary" type="submit">
                <i class="ri-send-plane-line"></i> Submit
            </button>
        </form>
    </div>

    <div class="col-md-6">
        <form id="form_privacy">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="privacy" class="form-label fw-bold">Privacy Policy</label>
                <textarea name="privacy" id="privacy" cols="30" rows="10" class="form-control"><?php echo e(old('privacy', $general->privacy)); ?></textarea>
                <small id="autosave-privacy" class="text-muted d-block mt-2 fst-italic">Belum ada penyimpanan
                    otomatis</small>
            </div>
            <button class="btn btn-primary" type="submit">
                <i class="ri-send-plane-line"></i> Submit
            </button>
        </form>
    </div>
</div>

<?php echo $__env->make('plugins.summernote', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {

            // === Inisialisasi Summernote ===
            $('#terms, #privacy').summernote({
                height: 250,
                placeholder: 'Tulis konten di sini...',
            });

            // === Fungsi Format Waktu ===
            function getCurrentTime() {
                const now = new Date();
                return now.toLocaleTimeString('id-ID', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                });
            }

            // === Fungsi Submit Reusable ===
            function submitForm(formId, autosave = false) {
                let form = $(formId);
                let formData = new FormData(form[0]);

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('other.update')); ?>",
                    data: formData,
                    contentType: false,
                    processData: false,
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        if (!autosave) {
                            Swal.fire({
                                position: "top-end",
                                icon: 'success',
                                title: 'Berhasil Disimpan!',
                                text: response.message || 'Data berhasil diperbarui.',
                                showConfirmButton: false,
                                timer: 1200,
                                toast: true,
                                background: '#28a745',
                                color: '#fff'
                            });
                        }

                        // Tampilkan indikator waktu autosave
                        const labelId = (formId === '#form_terms') ? '#autosave-terms' :
                            '#autosave-privacy';
                        $(labelId).text(`Draft disimpan otomatis pada ${getCurrentTime()}`);
                    },
                    error: function() {
                        if (!autosave) {
                            Swal.fire({
                                title: 'Error!',
                                text: 'Terjadi kesalahan. Silakan coba lagi.',
                                icon: 'error',
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                                toast: true,
                                background: '#dc3545',
                                color: '#fff'
                            });
                        }
                    }
                });
            }

            // === Manual Submit ===
            $('#form_terms').on('submit', function(e) {
                e.preventDefault();
                submitForm('#form_terms');
            });

            $('#form_privacy').on('submit', function(e) {
                e.preventDefault();
                submitForm('#form_privacy');
            });

            // === Auto-save jika ada perubahan ===
            let isChanged = {
                terms: false,
                privacy: false
            };

            $('#terms').on('summernote.change', function() {
                isChanged.terms = true;
            });

            $('#privacy').on('summernote.change', function() {
                isChanged.privacy = true;
            });

            // === Interval Auto-save setiap 30 detik ===
            setInterval(function() {
                if (isChanged.terms) {
                    submitForm('#form_terms', true);
                    isChanged.terms = false;
                }
                if (isChanged.privacy) {
                    submitForm('#form_privacy', true);
                    isChanged.privacy = false;
                }
            }, 30000); // 30 detik
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/admin/master/privacy.blade.php ENDPATH**/ ?>
<!-- Testimonials Section -->
<section id="testimonials" class="testimonials section">
    <!-- Section Title -->
    <div class="container section-title">
        <h2>Testimonials</h2>
        <p>Dengar langsung dari klien kami tentang pengalaman mereka bekerja dengan tim kami.</p>
    </div><!-- End Section Title -->

    <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row">
            <div class="col-12">
                <div class="testimonials-container">
                    <div class="swiper testimonials-slider init-swiper" data-aos="fade-up" data-aos-delay="400">

                        <script type="application/json" class="swiper-config">
                  {
                    "loop": true,
                    "speed": 600,
                    "autoplay": {
                      "delay": 5000
                    },
                    "slidesPerView": 1,
                    "spaceBetween": 30,
                    "pagination": {
                      "el": ".swiper-pagination",
                      "type": "bullets",
                      "clickable": true
                    },
                    "breakpoints": {
                      "768": {
                        "slidesPerView": 2
                      },
                      "992": {
                        "slidesPerView": 3
                      }
                    }
                  }
                </script>

                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $totalReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="testimonial-item">
                                        <div class="stars">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="bi bi-star<?php echo e($i <= $item->rating ? '-fill' : ''); ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <p>
                                            <?php echo e($item->testimoni); ?>

                                        </p>
                                        <div class="testimonial-profile">
                                            <?php if(!$item->foto): ?>
                                                <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>" alt="Reviewer"
                                                    class="img-fluid rounded-circle">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('uploads/testimonis/' . $item->foto)); ?>"
                                                    alt="Reviewer" class="img-fluid rounded-circle object-fit-cover">
                                            <?php endif; ?>
                                            <div>
                                                <h3><?php echo e($item->nama); ?></h3>
                                                <h4><?php echo e($item->epekerjaan); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- End testimonial item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 text-center" data-aos="fade-up">
                    <div class="overall-rating">
                        <div class="rating-number">
                            <!-- Menampilkan rata-rata rating dengan 1 angka desimal -->
                            <?php echo e(number_format($averageRating, 1)); ?>

                        </div>
                        <div class="rating-stars">
                            <!-- Menampilkan bintang penuh berdasarkan rating -->
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?php if($i <= floor($averageRating)): ?>
                                    <i class="bi bi-star-fill"></i>
                                <?php elseif($i == ceil($averageRating) && $averageRating - floor($averageRating) >= 0.5): ?>
                                    <i class="bi bi-star-half"></i>
                                <?php else: ?>
                                    <i class="bi bi-star"></i>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <p>Based on <?php echo e($totalReviews->count()); ?>+ reviews</p>
                        
                    </div>
                </div>

            </div>
        </div>
</section><!-- /Testimonials Section -->
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/homepage/testimonials.blade.php ENDPATH**/ ?>
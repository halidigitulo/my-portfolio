<div class="btn-group" role="group">
    <a href="<?php echo e(url('downloads/' . $filename)); ?>" class="btn btn-icon btn-sm btn-outline-primary me-1" target="_blank">
        <i class='bx  bx-arrow-down-stroke-circle'  ></i> 
    </a>
    <button class="btn btn-icon btn-sm btn-outline-danger btn-delete" data-file="<?php echo e($filename); ?>">
        <i class='bx  bx-trash'  ></i> 
    </button>
</div>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/admin/backup/actions.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Produk Kami'); ?>
<?php $__env->startSection('sub-title','Koleksi produk buatan kami yang mencerminkan kualitas dan dedikasi dalam setiap solusi digital.'); ?>
<?php $__env->startSection('meta_description',''); ?>
<?php $__env->startSection('meta_keywords',''); ?>
<?php $__env->startSection('content'); ?>

    <section id="starter-section" class="starter-section section">

        <!-- Section Title -->
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div><!-- End Section Title -->


        <div class="container py-5" data-aos="fade-up" data-aos-delay="100">
            <div class="row g-4" data-aos="fade-up" data-aos-delay="300">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="card product-card border-0 shadow-sm h-100 rounded-4 overflow-hidden position-relative">

                            <div class="card-img-wrapper overflow-hidden position-relative">
                                <?php if(!$item->thumbnail): ?>
                                    <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>" alt="<?php echo e($item->nama); ?>"
                                        class="card-img-top img-fluid hover-zoom">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('uploads/products/' . $item->thumbnail)); ?>" alt="<?php echo e($item->nama); ?>"
                                        class="card-img-top img-fluid hover-zoom">
                                <?php endif; ?>
                            </div>

                            <div class="card-body d-flex flex-column p-3">
                                <h5 class="fw-bold text-primary mb-2"><?php echo e($item->nama); ?></h5>

                                <p class="text-muted small flex-grow-1 mb-3">
                                    <?php echo \Illuminate\Support\Str::words(strip_tags($item->deskripsi), 30, '...'); ?>

                                </p>

                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="<?php echo e(asset('uploads/products/' . $item->thumbnail)); ?>"
                                        class="btn btn-light btn-sm rounded-pill px-3 shadow-sm glightbox"
                                        data-gallery="portfolio-gallery-ui"
                                        data-glightbox="title: <?php echo e($item->nama); ?>; description: <?php echo e($item->deskripsi); ?>">
                                        <i class="bi bi-arrows-angle-expand"></i> View
                                    </a>
                                    <a href="<?php echo e(route('product.detail', $item->slug)); ?>"
                                        class="btn btn-sm btn-danger rounded-pill px-3 shadow-sm">
                                        Detail <i class="bi bi-arrow-right-short"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/product/index.blade.php ENDPATH**/ ?>
 <!-- Contact Section -->
 <section id="contact" class="contact section light-background">

     <!-- Section Title -->
     <div class="container section-title">
         <h2>Contact</h2>
         <p>Jangan ragu menghubungi kami untuk solusi digital terbaik atau pertanyaan lebih lanjut.</p>
     </div><!-- End Section Title -->

     <div class="container" data-aos="fade-up" data-aos-delay="100">

         <?php echo $__env->make('front.others.contact-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div>

 </section><!-- /Contact Section -->
 

<?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/homepage/contact.blade.php ENDPATH**/ ?>
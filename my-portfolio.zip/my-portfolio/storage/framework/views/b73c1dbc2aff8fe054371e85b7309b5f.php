 <!-- Core JS -->
 <!-- build:js assets/vendor/js/core.js -->
 <script src="<?php echo e(asset('admin')); ?>/vendor/libs/jquery/jquery.js"></script>
 <script src="<?php echo e(asset('admin')); ?>/vendor/libs/popper/popper.js"></script>
 <script src="<?php echo e(asset('admin')); ?>/vendor/js/bootstrap.js"></script>
 <script src="<?php echo e(asset('admin')); ?>/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
 <script src="<?php echo e(asset('admin')); ?>/vendor/js/menu.js"></script>
 <script src="<?php echo e(asset('admin')); ?>/js/main.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
 <script src="https://cdn.datatables.net/2.1.4/js/dataTables.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>

 <?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\laragon\www\portfolio\resources\views/admin/partials/scripts.blade.php ENDPATH**/ ?>
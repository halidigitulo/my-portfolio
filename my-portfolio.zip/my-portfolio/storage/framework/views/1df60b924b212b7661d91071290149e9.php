<div class="row my-3">
    <div class="col">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kategori-stack.create')): ?>
            <button class="btn btn-primary mb-3" id="btn-add-kategori-stack"><i class="ri-add-line"></i> Add Data</button>
        <?php endif; ?>
        <div class="table-responsive-md">
            <table class="table table-sm table-hover table-striped" id="kategori-stack-table">
                <thead>
                    <tr>
                        <th width="5%">#</th>
                        <th>Icon</th>
                        <th>Kategori</th>
                        <th width="10%">Action</th>
                    </tr>
                </thead>
                
            </table>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="modalkategori-stack" tabindex="-1" aria-hidden="false">
            <div class="modal-dialog">
                <form id="formkategori-stack">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="ri-add-line"></i> Add Data</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="kategori-stack_id">
                            <input type="text" class="form-control mb-2" id="kategori-stack_icon"
                                placeholder="Icon" required>
                            <input type="text" class="form-control mb-2" id="kategori-stack_nama"
                                placeholder="Kategori stack" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary"><i class="ri-save-line"></i> Save</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i
                                    class="ri-close-line"></i> Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('style'); ?>
    <link href="https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.datatables.net/2.3.2/js/dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(function() {
            fetchData();

            function fetchData() {
                $(document).ready(function() {

                    $('#kategori-stack-table').DataTable({
                        processing: true,
                        serverSide: true,
                        ajax: {
                            url: '<?php echo e(route('kategori-stack.index')); ?>',
                            type: 'GET'
                        },
                        columns: [{
                                orderable: false,
                                render: function(data, type, row, meta) {
                                    return meta.row + meta.settings._iDisplayStart + 1;
                                }
                            },
                            {
                                data: 'icon',
                                name: 'icon'
                            },
                            {
                                data: 'nama',
                                name: 'nama'
                            },
                            {
                                data: 'aksi',
                                name: 'aksi'
                            }
                        ],
                        order: [
                            [0, 'asc']
                        ], // Default ordering by the second column (kode_bank)
                        responsive: true, // Makes the table responsive
                        autoWidth: false, // Prevents auto-sizing of columns
                        lengthMenu: [
                            [5, 10, 25, 50, -1],
                            [5, 10, 25, 50, "All"]
                        ], // Controls the page length options
                        pageLength: 5, // Default page length
                        // columnDefs: [{
                        //     targets: [0, 1, 2], // Adjust column indexes as needed
                        //     className: 'center-align'
                        // }]
                    });
                });
            }

            $('#btn-add-kategori-stack').click(() => {
                $('#modalkategori-stack').modal('show');
                $('#formkategori-stack')[0].reset();
                $('#kategori-stack_id').val('');
                $('.modal-title').text('Add Data');
            });

            $(document).on('click', '.edit-kategori-stack', function() {
                let id = $(this).data('id');
                $.get(`/admin/kategori-stack/${id}`, function(data) {
                    $('#modalkategori-stack').modal('show');
                    $('.modal-title').text('Edit Data');
                    $('#kategori-stack_id').val(data.id);
                    $('#kategori-stack_nama').val(data.nama);
                    $('#kategori-stack_icon').val(data.icon);
                });
            });

            $('#formkategori-stack').submit(function(e) {
                e.preventDefault();
                let id = $('#kategori-stack_id').val();
                let url = id ? `/admin/kategori-stack/${id}` : `<?php echo e(route('kategori-stack.store')); ?>`;
                let method = id ? 'PUT' : 'POST';

                $.ajax({
                    url,
                    type: 'POST',
                    data: {
                        _token: $('input[name=_token]').val(),
                        _method: method,
                        nama: $('#kategori-stack_nama').val(),
                        icon: $('#kategori-stack_icon').val(),
                    },
                    success: function(res) {
                        $('#kategori-stack-table').DataTable().ajax.reload();
                        Swal.fire({
                            title: 'Success!',
                            text: res.message,
                            icon: 'success',
                            timer: 3000,
                            toast: true,
                            position: 'top-end',
                        });
                        $('#modalkategori-stack').modal('hide');
                        $('#formkategori-stack')[0].reset(); // Reset form
                    },
                    error: function(err) {
                        Swal.fire('Error', 'Failed to save kategori-stack', 'error');
                    }
                });
            });

            $(document).on('click', '.hapus-kategori-stack', function() {
                let id = $(this).data('id');
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'This action cannot be undone!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!',
                }).then(result => {
                    if (result.isConfirmed) {
                        $.post(`/admin/kategori-stack/${id}`, {
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: "DELETE"
                        }, function(response) {
                            $('#kategori-stack-table').DataTable().ajax.reload();
                            Swal.fire('Deleted!', response.message, 'success');
                            // fetchData();
                        });
                    }
                });
            });

        });

        $('#modalkategori-stack').on('hidden.bs.modal', function() {
            // Arahkan fokus ke tombol pemicu modal
            $('#btnOpenModal').focus();
        });

        $('#modalkategori-stack').on('hide.bs.modal', function() {
            $(this).find(':focus').blur();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\my-portfolio\resources\views/admin/master/kategori-stack.blade.php ENDPATH**/ ?>
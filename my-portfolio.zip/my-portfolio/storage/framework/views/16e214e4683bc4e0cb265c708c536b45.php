<?php $__env->startSection('title', 'Product Detail - ' . $data->nama); ?>
<?php $__env->startSection('content'); ?>
    <section id="starter-section" class="starter-section section">
        <!-- Section Title -->
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div><!-- End Section Title -->
        <section id="service-details" class="service-details section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="row gy-5">
                    <div class="col-lg-8" data-aos="fade-left" data-aos-delay="200">
                        <div class="service-hero">
                            <?php if(!$data->thumbnail): ?>
                                <img src="<?php echo e(asset('uploads/' . $profile->logo)); ?>" alt="<?php echo e($profile->nama); ?>"
                                    class="img-fluid">
                            <?php else: ?>
                                <img src="<?php echo e(asset('uploads/products/' . $data->thumbnail)); ?>" alt="<?php echo e($profile->nama); ?>"
                                    class="img-fluid">
                            <?php endif; ?>
                            <div class="service-badge">
                                <span><?php echo e($data->nama); ?> by <?php echo e($profile->nama); ?></span>
                            </div>
                        </div>
                        <div class="service-content">
                            <div class="service-features">
                                <p><?php echo $data->deskripsi; ?></p>
                            </div>
                            <div class="cta-buttons" data-aos="fade-up" data-aos-delay="400">
                                <a href="<?php echo e(route('product.listing')); ?>" class="btn btn-danger"><i class="bi bi-list"></i>
                                    Show All Products</a>

                                
                                <?php if($nextProduct): ?>
                                    <a href="<?php echo e(route('product.detail', $nextProduct->slug)); ?>" class="btn btn-primary">
                                        Next Product <i class="bi bi-arrow-right"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <?php echo $__env->make('front.partials.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/product/detail.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Hubungi Kami'); ?>
<?php $__env->startSection('sub-title', 'Get in Touch with Us'); ?>
<?php $__env->startSection('meta_description',
    'Reach out to us for any inquiries, support, or feedback. We are here to assist you and
    ensure you have the best experience with our services.'); ?>
<?php $__env->startSection('meta_keywords', 'contact, support, inquiries, feedback, customer service, help, get in touch'); ?>
<?php $__env->startSection('content'); ?>

    <section class="starter-section section">
        <div class="container section-title">
            <h2><?php echo $__env->yieldContent('title'); ?></h2>
            <p><?php echo $__env->yieldContent('sub-title'); ?></p>
        </div>

        <section id="service-details" class="service-details section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row gy-5">
                    <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
                        <div class="row">
                            <div class="col-md-12 d-flex align-items-center" data-aos="fade-up" data-aos-delay="200">
                                <div class="icon-box me-3">
                                    <i class="bi bi-geo-alt text-danger fs-4"></i>
                                </div>
                                <div class="content">
                                    <h4>Alamat Kami</h4>
                                    <p><?php echo e($profile->alamat); ?></p>
                                    <p><?php echo e($profile->kota); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 d-flex align-items-center" data-aos="fade-up" data-aos-delay="300">
                                <div class="icon-box me-3">
                                    <i class="bi bi-telephone text-danger fs-4"></i>
                                </div>
                                <div class="content">
                                    <h4>No. Telp / WA</h4>
                                    <p><a href="tel:<?php echo e($profile->telp); ?>"></a><?php echo e($profile->telp); ?></p>
                                    <p><?php echo e($profile->hp); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6 d-flex align-items-center" data-aos="fade-up" data-aos-delay="300">
                                <div class="icon-box me-3">
                                    <i class="bi bi-envelope text-danger fs-4"></i>
                                </div>
                                <div class="content">
                                    <h4>Email</h4>
                                    <p><?php echo e($profile->email); ?></p>
                                    
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="service-content">
                            <div class="service-features">
                                <iframe src="<?php echo e($profile->maps); ?>" width="100%" height="450"
                                    style="border:0; border-radius: 10px;" allowfullscreen="" loading="lazy"
                                    referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('front.others.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </section><!-- /Service Details Section -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.partials.starter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\my-portfolio\resources\views/front/others/contact.blade.php ENDPATH**/ ?>